JavaScript must be used to scroll the table headers as the table body scrolls.
