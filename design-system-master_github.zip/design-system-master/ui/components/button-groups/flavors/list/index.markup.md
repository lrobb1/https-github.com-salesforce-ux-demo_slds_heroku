The list variant of button groups puts the buttons in an unordered list. This is the recommended variant for menus.
