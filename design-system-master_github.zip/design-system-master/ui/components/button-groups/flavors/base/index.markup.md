If the last button is wrapped in another element (for example, a `div` holding a dropdown menu), place the `.slds-button--last` class on the wrapping element instead.

For the inverse version of the button group, use the `.slds-button--inverse` class.

Note: The inverse group is seen on the edit dashboard. The disabled attribute might not be applicable in this situation.
