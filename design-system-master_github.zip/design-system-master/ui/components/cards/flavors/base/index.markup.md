The base card is used primarily on desktop within a &ldquo;wide&rdquo; column or &ldquo;main content area&rdquo;, which uses two-thirds of the viewport.
