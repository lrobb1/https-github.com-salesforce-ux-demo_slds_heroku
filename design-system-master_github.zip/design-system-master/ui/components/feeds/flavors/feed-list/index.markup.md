A discussion feed consists of a list of posts. A `.slds-feed__item` contains a post and comments related to that post.
